#include <cstdlib>
#include "src/ui.hpp"

int main() {
    printf("yes\n");
    sf::RenderWindow window(sf::VideoMode(800, 600), "Luis", sf::Style::Titlebar | sf::Style::Close);
    sf::Event event;

    TextInput b(10,10,200,200);

    sf::Font font;
    if (!font.loadFromFile("assets/bebasneue.ttf")) {
        printf("Font bebasneue.ttf is missing...\n");
        return 1;
    }

    while(window.isOpen()) {
        while(window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) window.close();
        }

        window.clear();
        b.draw(FrameState(&window, &font));
        window.display();
    }

    return 0;
}
