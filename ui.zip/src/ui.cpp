#include "ui.hpp"

/* Base UI Element */

Element::Element(int x, int y, int w, int h) {
    m_rect = sf::Rect<int>(x, y, w, h);
}

Element::Element(sf::Rect<int> rect) {
    m_rect = rect;
}

/* Button */

Button::Button(int x, int y, int w, int h, std::string text) : Element(x, y, w, h) {
    m_text = text;
}

Button::Button(sf::Rect<int> rect, std::string text) : Element(rect) {
    m_text = text;
}

void Button::draw(FrameState state) {
    sf::RectangleShape rectangle;
    rectangle.setPosition(m_rect.left, m_rect.top);
    rectangle.setSize(sf::Vector2f(m_rect.width, m_rect.height));
    rectangle.setFillColor(sf::Color(0,0,0));
    rectangle.setOutlineColor(sf::Color::White);
    rectangle.setOutlineThickness(1);

    sf::Text label(m_text, *state.font);
    label.setCharacterSize(12);
    label.setFillColor(sf::Color(255,255,255));
    sf::FloatRect bounds = label.getLocalBounds();
    label.setPosition(
        (int)(m_rect.left + m_rect.width/2 - bounds.width/2),
        (int)(m_rect.top + m_rect.height/2 - bounds.height/2)
    );

    if (this->clicked(state.surface)) {
        rectangle.setFillColor(sf::Color(255,255,255));
        label.setFillColor(sf::Color(0,0,0));
    }

    state.surface->draw(rectangle);
    state.surface->draw(label);
}

bool Button::clicked(sf::RenderWindow *surface) {
    return (
        sf::Mouse::isButtonPressed(sf::Mouse::Left) &&
        m_rect.contains(sf::Mouse::getPosition(*surface))
    );
}

void Button::set_text(std::string text) {m_text = text;}
void Button::set_textsize(int size) {m_textsize = size;}

/* Text Input */

void TextInput::draw(FrameState state) {
    // Check for user input
    for (int i = 0; i < 26; i++) {
        // ah yes, making a ui library is a fucking pain in the ass
        // imma zip this file, add it to the repo and forget about it
        // I'll look for a premade ui library
        // all this work goes to waste :D
    }

    // Draw
    sf::RectangleShape rectangle;
    rectangle.setPosition(m_rect.left, m_rect.top);
    rectangle.setSize(sf::Vector2f(m_rect.width, m_rect.height));
    rectangle.setFillColor(sf::Color(255,255,255));
    rectangle.setOutlineColor(sf::Color::White);
    rectangle.setOutlineThickness(1);

    sf::Text label(m_text, *state.font);
    label.setCharacterSize(12);
    label.setFillColor(sf::Color(0,0,0));
    sf::FloatRect bounds = label.getLocalBounds();
    label.setPosition(
        (int)(m_rect.left + m_rect.width/2 - bounds.width/2),
        (int)(m_rect.top + m_rect.height/2 - bounds.height/2)
    );

    state.surface->draw(rectangle);
    state.surface->draw(label);
}
