#include <SFML/Window/Keyboard.hpp>
#include <SFML/Window/Mouse.hpp>
#include <SFML/Graphics.hpp>
#include <string>
#include "helper.hpp"

class Element {
public:
    Element(int x=0, int y=0, int w=10, int h=10);
    Element(sf::Rect<int> rect);
    virtual void draw(FrameState state) {}

    void set_coordinates(int x, int y) {
        m_rect.left = x;
        m_rect.top = y;
    }
    void set_size(int w, int h) {
        m_rect.width = w;
        m_rect.height = h;
    }
    void set_rect(sf::Rect<int> rect) m_rect = rect;

protected:
    sf::Rect<int> m_rect;
    double timer;
};


class Button : public Element {
public:
    Button(int x=0, int y=0, int w=10, int h=10, std::string text="");
    Button(sf::Rect<int> rect, std::string text);
    void draw(FrameState state);
    bool clicked(sf::RenderWindow *surface);

    void set_text(std::string text);
    void set_textsize(int size);

protected:
    std::string m_text;
    int m_textsize=12;
};


class TextInput : public Element {
public:
    TextInput(int x=0, int y=0, int w=10, int h=10) : Element(x,y,w,h) {}
    TextInput(sf::Rect<int> rect) : Element(rect) {}
    void draw(FrameState state);

    void make_active(bool active=true) m_active = active;
    void set_textsize(int size);
    std::string get_text();

protected:
    std::string m_text;
    bool active=false;
    int m_textsize=12;
};
