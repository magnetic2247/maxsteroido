#!/bin/sh
mkdir -p bin
g++ -lm -lsfml-graphics -lsfml-window -lsfml-system dev.cpp src/ui.cpp -o bin/dev
